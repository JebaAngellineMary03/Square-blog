<!DOCTYPE html>
<html xml:lang="en" lang="en" class="">
<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
	<meta name="HandheldFriendly" content="true" >
	<meta name="MobileOptimized" content="width">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<title>Website</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script data-skip-moving="true">(function() {const canvas = document.createElement('canvas');let gl;try{gl = canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl');}catch (e){return;}if (!gl){return;}const result = {vendor: gl.getParameter(gl.VENDOR),renderer: gl.getParameter(gl.RENDERER),};const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');if (debugInfo){result.unmaskedVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);result.unmaskedRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);}function isLikelyIntegratedGPU(gpuInfo){const renderer = (gpuInfo.unmaskedRenderer || gpuInfo.renderer || '').toLowerCase();const vendor = (gpuInfo.unmaskedVendor || gpuInfo.vendor || '').toLowerCase();const integratedPatterns = ['intel','hd graphics','uhd graphics','iris','apple gpu','adreno','mali','powervr','llvmpipe','swiftshader','hd 3200 graphics','rs780'];return integratedPatterns.some(pattern => renderer.includes(pattern) || vendor.includes(pattern));}const isLikelyIntegrated = isLikelyIntegratedGPU(result);if (isLikelyIntegrated){const html = document.documentElement;html.classList.add('bx-integrated-gpu', '--ui-reset-bg-blur');}})();</script>
<script data-skip-moving="true">(function(w, d, n) {var cl = "bx-core";var ht = d.documentElement;var htc = ht ? ht.className : undefined;if (htc === undefined || htc.indexOf(cl) !== -1){return;}var ua = n.userAgent;if (/(iPad;)|(iPhone;)/i.test(ua)){cl += " bx-ios";}else if (/Windows/i.test(ua)){cl += ' bx-win';}else if (/Macintosh/i.test(ua)){cl += " bx-mac";}else if (/Linux/i.test(ua) && !/Android/i.test(ua)){cl += " bx-linux";}else if (/Android/i.test(ua)){cl += " bx-android";}cl += (/(ipad|iphone|android|mobile|touch)/i.test(ua) ? " bx-touch" : " bx-no-touch");cl += w.devicePixelRatio && w.devicePixelRatio >= 2? " bx-retina": " bx-no-retina";if (/Safari/i.test(ua) && !/Chrome/i.test(ua)){cl += " bx-safari";}else if (/AppleWebKit/.test(ua)){cl += " bx-chrome";}else if (/Opera/.test(ua)){cl += " bx-opera";}else if (/Firefox/.test(ua)){cl += " bx-firefox";}ht.className = htc ? htc + " " + cl : cl;})(window, document, navigator);</script>


<link href="/bitrix/js/intranet/intranet-common.min.css?166151605361199" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/design-tokens/dist/ui.design-tokens.min.css?171327662823463" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/intranet/design-tokens/bitrix24/air-design-tokens.min.css?17539754263744" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/fonts/opensans/ui.font.opensans.min.css?16620208132320" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/design-tokens/air/dist/air-design-tokens.min.css?1762777376109604" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/main/popup/dist/main.popup.bundle.min.css?174532104928056" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/switcher/dist/ui.switcher.bundle.min.css?17640822106763" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/cnt/ui.cnt.min.css?17473213844259" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/cnt/dist/cnt.bundle.min.css?17495470375784" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/icon-set/icon-base.min.css?17627773751877" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/icon-set/outline/style.min.css?1769420575112666" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/icon-set/main/style.min.css?174732138474857" type="text/css" rel="stylesheet"/>
<link href="/bitrix/js/ui/buttons/dist/ui.buttons.bundle.min.css?176408221072758" type="text/css" rel="stylesheet"/>
<link href="/bitrix/components/bitrix/landing.pub/templates/.default/style.min.css?176043320543453" type="text/css" rel="stylesheet"/>
<link href="/bitrix/templates/landing24/template_styles.min.css?16843044572401" type="text/css" rel="stylesheet" data-template-style="true"/>







</head>
<body class="" >
<main class="w-100 " style="height: 100vh; background: #fff;">

	<!-- ico 'SITE was not found' -->
	<div class="landing-error-site">
		<div class="landing-error-site-img">
			<div class="landing-error-site-img-inner"></div>
		</div>
		<div class="landing-error-site-title">This link doesn't appear to open any page.</div>
		<div class="landing-error-site-desc">
			Check the link address or get back to the <a href="https://snsihub.ai">index page</a>.		</div>
	</div>


</main>


<script>if(!window.BX)window.BX={};if(!window.BX.message)window.BX.message=function(mess){if(typeof mess==='object'){for(let i in mess) {BX.message[i]=mess[i];} return true;}};</script>
<script>(window.BX||top.BX).message({"JS_CORE_LOADING":"Loading...","JS_CORE_WINDOW_CLOSE":"Close","JS_CORE_WINDOW_EXPAND":"Expand","JS_CORE_WINDOW_NARROW":"Restore","JS_CORE_WINDOW_SAVE":"Save","JS_CORE_WINDOW_CANCEL":"Cancel","JS_CORE_H":"h","JS_CORE_M":"m","JS_CORE_S":"s","JS_CORE_NO_DATA":"- No data -","JSADM_AI_HIDE_EXTRA":"Hide extra items","JSADM_AI_ALL_NOTIF":"All notifications","JSADM_AUTH_REQ":"Authentication is required!","JS_CORE_WINDOW_AUTH":"Log In","JS_CORE_IMAGE_FULL":"Full size","JS_CORE_WINDOW_CONTINUE":"Continue"});</script><script src="/bitrix/js/main/core/core.min.js?1769512295245648"></script><script>BX.Runtime.registerExtension({"name":"main.core","namespace":"BX","loaded":true});</script>
<script>BX.setJSList(["\/bitrix\/js\/main\/core\/core_ajax.js","\/bitrix\/js\/main\/core\/core_promise.js","\/bitrix\/js\/main\/polyfill\/promise\/js\/promise.js","\/bitrix\/js\/main\/loadext\/loadext.js","\/bitrix\/js\/main\/loadext\/extension.js","\/bitrix\/js\/main\/polyfill\/promise\/js\/promise.js","\/bitrix\/js\/main\/polyfill\/find\/js\/find.js","\/bitrix\/js\/main\/polyfill\/includes\/js\/includes.js","\/bitrix\/js\/main\/polyfill\/matches\/js\/matches.js","\/bitrix\/js\/ui\/polyfill\/closest\/js\/closest.js","\/bitrix\/js\/main\/polyfill\/fill\/main.polyfill.fill.js","\/bitrix\/js\/main\/polyfill\/find\/js\/find.js","\/bitrix\/js\/main\/polyfill\/matches\/js\/matches.js","\/bitrix\/js\/main\/polyfill\/core\/dist\/polyfill.bundle.js","\/bitrix\/js\/main\/core\/core.js","\/bitrix\/js\/main\/polyfill\/intersectionobserver\/js\/intersectionobserver.js","\/bitrix\/js\/main\/lazyload\/dist\/lazyload.bundle.js","\/bitrix\/js\/main\/polyfill\/core\/dist\/polyfill.bundle.js","\/bitrix\/js\/main\/parambag\/dist\/parambag.bundle.js"]);
</script>
<script>BX.Runtime.registerExtension({"name":"ui.dexie","namespace":"BX.DexieExport","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"fc","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"pull.protobuf","namespace":"BX","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"rest.client","namespace":"window","loaded":true});</script>
<script>(window.BX||top.BX).message({"pull_server_enabled":"Y","pull_config_timestamp":1769531010,"shared_worker_allowed":"Y","pull_guest_mode":"N","pull_guest_user_id":0,"pull_worker_mtime":1743166765});(window.BX||top.BX).message({"PULL_OLD_REVISION":"This page must be reloaded to ensure proper site functioning and to continue work."});</script>
<script>BX.Runtime.registerExtension({"name":"pull.client","namespace":"BX","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"pull","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"intranet.design-tokens.bitrix24","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.design-tokens","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.fonts.opensans","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.design-tokens.air","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.icon-set.api.core","namespace":"BX.UI.IconSet","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"main.popup","namespace":"BX.Main","loaded":true});</script>
<script>(window.BX||top.BX).message({"UI_SWITCHER_ON":"on","UI_SWITCHER_OFF":"off"});(window.BX||top.BX).message({"UI_SWITCHER_ON":"on","UI_SWITCHER_OFF":"off"});</script>
<script>BX.Runtime.registerExtension({"name":"ui.switcher","namespace":"BX.UI","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.cnt","namespace":"BX.UI","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.icon-set","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.icon-set.outline","namespace":"window","loaded":true});</script>
<script>BX.Runtime.registerExtension({"name":"ui.icon-set.main","namespace":"window","loaded":true});</script>
<script>(window.BX||top.BX).message({"UI_BUTTONS_SAVE_BTN_TEXT":"Save","UI_BUTTONS_CREATE_BTN_TEXT":"Create","UI_BUTTONS_ADD_BTN_TEXT":"Add","UI_BUTTONS_SEND_BTN_TEXT":"Send","UI_BUTTONS_CANCEL_BTN_TEXT":"Cancel","UI_BUTTONS_CLOSE_BTN_TEXT":"Close","UI_BUTTONS_APPLY_BTN_TEXT":"Apply"});</script>
<script>BX.Runtime.registerExtension({"name":"ui.buttons","namespace":"BX.UI","loaded":true});</script>
<script>(window.BX||top.BX).message({"LANGUAGE_ID":"en","FORMAT_DATE":"DD\/MM\/YYYY","FORMAT_DATETIME":"DD\/MM\/YYYY H:MI:SS T","COOKIE_PREFIX":"BITRIX_SM","SERVER_TZ_OFFSET":"10800","UTF_MODE":"Y","SITE_ID":"s1","SITE_DIR":"\/","USER_ID":"","SERVER_TIME":1770368130,"USER_TZ_OFFSET":0,"USER_TZ_AUTO":"Y","bitrix_sessid":"c52d89dbb6c1cc57b8b938f47a9aae2a"});</script><script src="/bitrix/js/ui/dexie/dist/dexie.bundle.min.js?1744124719102530"></script>
<script src="/bitrix/js/main/core/core_frame_cache.min.js?177003817410246"></script>
<script src="/bitrix/js/pull/protobuf/protobuf.js?1592315491274055"></script>
<script src="/bitrix/js/pull/protobuf/model.min.js?159231549114190"></script>
<script src="/bitrix/js/rest/client/rest.client.min.js?16015491189240"></script>
<script src="/bitrix/js/pull/client/pull.client.min.js?174471771449849"></script>
<script src="/bitrix/js/ui/icon-set/api/core/dist/ui.icon-set.core.bundle.min.js?176942057643597"></script>
<script src="/bitrix/js/main/popup/dist/main.popup.bundle.min.js?176960609467330"></script>
<script src="/bitrix/js/ui/switcher/dist/ui.switcher.bundle.min.js?17640822108553"></script>
<script src="/bitrix/js/ui/cnt/dist/cnt.bundle.min.js?174954703710460"></script>
<script src="/bitrix/js/ui/buttons/dist/ui.buttons.bundle.min.js?176942057561326"></script>
<script>
					if (Intl && Intl.DateTimeFormat)
					{
						const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
						document.cookie = "BITRIX_SM_TZ=" + timezone + "; path=/; expires=Mon, 01 Feb 2027 00:00:00 +0300";
						
					}
				</script>



<script src="/bitrix/components/bitrix/landing.pub/templates/.default/script.min.js?17126771928487"></script>

<script>
	(function()
	{
		if (window.location.hash.indexOf('#landingId') === 0)
		{
			window.location.href = BX.Uri.addParam(
				window.location.href,
				{
					forceLandingId: window.location.hash.substr(
						'#landingId'.length
					)
				}
			);
			window.location.hash = '';
		}
	})();
</script>
</body>
</html>
