<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Bitrix24 - account does not exist or has been deleted</title>
	<link rel="stylesheet" href="">
	<style>
			body{margin: 0;padding: 0;font-family:  "Helvetica Neue", Helvetica, Arial,sans-serif;}
			section{width: 100%; border-bottom: 1px solid #eaf0f3;}
			body section:last-child{border: none;}
			section>div{width: 860px;margin: 0 auto; color: #6a828c;font-size: 16px;padding: 40px 0;}
			table{width: 860px;margin: 30px auto;}
			.t1{font-size: 18px;color: #6a828c;padding-left:80px;}
			.t2{font-size: 18px;color: #272b2d;}
			.t3{width:390px;text-align: center;}
			.bx-btn{
				font-family:'Open Sans', Helvetica, Arial, sans-serif;
				font-size:11px;
				font-weight:bold;
				line-height:32px;
				position:relative;
				display:inline-block;
				-webkit-box-sizing:border-box;
				   -moz-box-sizing:border-box;
						box-sizing:border-box;
				height:32px;
				padding:0 15px;
				cursor:pointer;
				-webkit-transition:border .3s ease, background-color .3s ease, color .3s ease;
				   -moz-transition:border .3s ease, background-color .3s ease, color .3s ease;
					-ms-transition:border .3s ease, background-color .3s ease, color .3s ease;
					 -o-transition:border .3s ease, background-color .3s ease, color .3s ease;
						transition:border .3s ease, background-color .3s ease, color .3s ease;
				text-align:center;
				vertical-align:middle;
				text-decoration:none;
				text-transform:uppercase;
				color:#fff;
				border:none;
				border-radius:2px;
				background-color:#868d95;
				outline: none;
			}

			.bx-btn:hover {background-color:#5b6573;color:#fff;}
			.bx-btn:active{background-color:#3b506e;color:#fff;outline: none;}
			.bx-btn.xbig	{line-height:48px;height:48px;font-size:14px;}
			.bx-btn.big	{line-height:40px;height:40px;font-size:12px;}
			.bx-btn.green,		 .bx-btn.arrow.green	 	span{background-color:#bbed21;color: #535b69;}
			.bx-btn.green:hover, .bx-btn.arrow.green:hover  span{background-color:#d2f95f;color: #535b69;}
			.bx-btn.green:active,.bx-btn.arrow.green:active span{background-color:#b2e233;color: #535b69;}

	</style>
	<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	ga('create', 'UA-113563-6', 'auto', {'allowLinker': true});
	ga('require', 'ecommerce', 'ecommerce.js');
	ga('require', 'linker');
	ga('linker:autoLink', ['www.bitrix24.net'] );
	ga('send', 'pageview');
	</script>
</head>
<body>

	<section>
		<table>
			<tr>
				<td><img src="/custom_error_pages/403_en.png" alt=""></td>
				<td class="t1">
					This  account does not exist or has been deleted.<br>
					Please check if you've entered your Bitrix24 account address correctly.
				</td>
			</tr>
		</table>
	<section>

	</section>
		<table>
			<tr>
				<td class="t2">
					If you want to create your own Bitrix24.Site, you can register your Bitrix24 right now.
				</td>
				<td class="t3"><a href="https://www.bitrix24.net/create/?tab=email&user_lang=en" class="bx-btn xbig green" onclick="ga('send', 'event', 'Registration', 'portal404');">Create Bitrix24 account</a></td>
			</tr>
		</table>
	</section>

	
</body>
</html>